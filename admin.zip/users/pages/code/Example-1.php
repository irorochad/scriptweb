<?php 

    // how to use image from example 001 
    echo '<img src="QRCodeGenerate.php" />';

?>